# Kalale Research — Website + Backend

The full site: the static frontend in `public/index.html` plus a small
Node/Express backend that powers the two working forms on the site
("Subscribe to Field Notes" and "Request coverage"). No database or
external accounts required to run it.

## What the backend actually does

- `POST /api/subscribe` — validates the email, de-dupes against existing
  subscribers, and appends it to `server/data/subscribers.json`.
- `POST /api/coverage-request` — validates name/email/target, appends the
  request to `server/data/coverage-requests.json`.
- `GET /api/health` — returns `{ status: "ok" }`, useful for uptime checks.
- Serves the site itself (`public/index.html` and its assets) on `/`.

Both write endpoints have:
- Input validation (rejects missing/malformed fields with a 400 and a
  clear error message)
- A hidden honeypot field (`website`) that silently drops bot submissions
- Rate limiting (10 requests / 15 min / IP)
- Security headers via Helmet, including a Content-Security-Policy

Data is stored as plain JSON files under `server/data/` — no database
setup needed. That's enough for a low-volume site; if volume grows, swap
`server/store.js` for a real database without touching the routes (they
only call `.append()` / `.all()`).

## Run it locally

```bash
npm install
npm start
```

Then open **http://localhost:3000** — that's the whole site, served by
the same process that runs the API. Nothing else to start.

`npm run dev` restarts the server automatically on file changes (uses
Node's built-in `--watch`, no extra dependency).

## Configuration

Copy `.env.example` to `.env` if you want to change anything — the app
runs with sensible defaults even without a `.env` file:

```bash
cp .env.example .env
```

- `PORT` — defaults to `3000`
- `CORS_ORIGINS` — only needed if you'll call the API from a different
  origin than the one serving the site (e.g. a separate frontend deploy).
  Leave blank for the default same-origin setup.
- `NODE_ENV` — set to `production` when deploying.

## Deploying

This is a standard Node/Express app — it runs anywhere Node runs
(Render, Railway, Fly.io, a VPS, etc.):

1. Push this folder to your host of choice.
2. Set `NODE_ENV=production` (and `PORT` if your host requires a specific
   one — most inject `PORT` automatically).
3. Build/start command: `npm install && npm start`.

**One thing to know about the JSON storage:** on hosts with an ephemeral
filesystem (e.g. most container platforms redeploy with a fresh disk),
`server/data/*.json` will reset on each deploy. Fine for testing; before
relying on it in production, either mount a persistent volume for
`server/data/`, or swap in a real database (Postgres/SQLite) — the
`store.js` module is the only file that would need to change.

## Project structure

```
kalale-research/
├── public/
│   └── index.html          # the site (forms wired to the API below)
├── server/
│   ├── index.js             # Express app: security headers, routes, static serving
│   ├── store.js              # tiny JSON-file storage helper
│   ├── middleware/
│   │   └── validate.js       # input validation + honeypot check
│   ├── routes/
│   │   ├── subscribe.js
│   │   └── coverageRequest.js
│   └── data/                 # subscribers.json / coverage-requests.json (created at runtime)
├── package.json
├── .env.example
└── README.md
```

## Extending it later

- **Email confirmation on subscribe:** there's a marked hook point in
  `server/routes/subscribe.js` — add `nodemailer` and your SMTP creds to
  `.env` there.
- **Admin view of submissions:** the JSON files are just arrays of
  objects — trivial to read into a small `/admin` page or export to CSV
  later if you want one.
