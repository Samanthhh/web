'use strict';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_LEN = {
  email: 254,
  name: 120,
  target: 200,
  message: 2000,
};

function isNonEmptyString(v) {
  return typeof v === 'string' && v.trim().length > 0;
}

function isValidEmail(v) {
  return isNonEmptyString(v) && v.trim().length <= MAX_LEN.email && EMAIL_RE.test(v.trim());
}

function clamp(v, max) {
  return typeof v === 'string' ? v.trim().slice(0, max) : '';
}

/** Reject requests where the honeypot field was filled in (bot submissions). */
function rejectHoneypot(req, res, next) {
  if (isNonEmptyString(req.body && req.body.website)) {
    // Respond as if it succeeded so bots don't learn the trap worked, but do nothing.
    return res.status(200).json({ ok: true });
  }
  next();
}

function validateSubscribe(req, res, next) {
  const { email } = req.body || {};
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'A valid email address is required.' });
  }
  req.body.email = email.trim().toLowerCase();
  next();
}

function validateCoverageRequest(req, res, next) {
  const { name, email, target, message } = req.body || {};
  const errors = [];
  if (!isNonEmptyString(name)) errors.push('name');
  if (!isValidEmail(email)) errors.push('email');
  if (!isNonEmptyString(target)) errors.push('target');
  if (errors.length) {
    return res.status(400).json({
      error: `Missing or invalid field(s): ${errors.join(', ')}.`,
    });
  }
  req.body = {
    name: clamp(name, MAX_LEN.name),
    email: email.trim().toLowerCase(),
    target: clamp(target, MAX_LEN.target),
    message: clamp(message || '', MAX_LEN.message),
  };
  next();
}

module.exports = {
  isValidEmail,
  rejectHoneypot,
  validateSubscribe,
  validateCoverageRequest,
};
