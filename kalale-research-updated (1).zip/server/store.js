'use strict';

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');

/**
 * Minimal JSON-file-backed store. Not a database — fine for a low-volume
 * newsletter/coverage-request list. Each named store is its own file and
 * writes are serialized per-file so concurrent requests never corrupt it.
 */
class JSONStore {
  constructor(fileName) {
    this.filePath = path.join(DATA_DIR, fileName);
    this._queue = Promise.resolve();
    this._ensureFile();
  }

  _ensureFile() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(this.filePath)) {
      fs.writeFileSync(this.filePath, '[]\n', 'utf8');
    }
  }

  _readSync() {
    try {
      const raw = fs.readFileSync(this.filePath, 'utf8');
      return raw.trim() ? JSON.parse(raw) : [];
    } catch (err) {
      // Corrupt or empty file — fail safe to an empty list rather than crash.
      return [];
    }
  }

  _writeSync(records) {
    const tmpPath = this.filePath + '.tmp';
    fs.writeFileSync(tmpPath, JSON.stringify(records, null, 2) + '\n', 'utf8');
    fs.renameSync(tmpPath, this.filePath); // atomic on POSIX filesystems
  }

  /** Run `fn` exclusively against this store, serialized after prior calls. */
  _run(fn) {
    const result = this._queue.then(() => fn());
    // Keep the queue alive even if `fn` rejects, so later calls still run.
    this._queue = result.then(() => undefined, () => undefined);
    return result;
  }

  all() {
    return this._run(() => this._readSync());
  }

  /**
   * Append a record if `isDuplicate(existing, record)` returns false for
   * every existing entry. Returns { record, duplicate: boolean }.
   */
  append(record, isDuplicate) {
    return this._run(() => {
      const records = this._readSync();
      if (typeof isDuplicate === 'function') {
        const dup = records.find((r) => isDuplicate(r, record));
        if (dup) return { record: dup, duplicate: true };
      }
      records.push(record);
      this._writeSync(records);
      return { record, duplicate: false };
    });
  }
}

module.exports = { JSONStore };
