'use strict';

require('dotenv').config();

const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');

const subscribeRoute = require('./routes/subscribe');
const coverageRequestRoute = require('./routes/coverageRequest');

const app = express();
const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

const corsOrigins = (process.env.CORS_ORIGINS || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

// ---- Security headers ----
// The site inlines base64 images and a small script, so we relax the
// default script-src to 'self' only (no inline scripts are needed since
// the JS lives in a <script> tag in the same document — keep CSP simple
// and permissive for images/data URIs which the design relies on).
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        connectSrc: ["'self'"],
      },
    },
  })
);

// ---- CORS ----
// If CORS_ORIGINS is unset, the API only needs to work for same-origin
// requests from the site it's serving, so we skip strict CORS entirely.
if (corsOrigins.length) {
  app.use(
    cors({
      origin: corsOrigins,
      methods: ['GET', 'POST'],
    })
  );
}

// ---- Logging ----
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ---- Body parsing ----
app.use(express.json({ limit: '20kb' }));

// ---- API routes ----
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});
app.use('/api/subscribe', subscribeRoute);
app.use('/api/coverage-request', coverageRequestRoute);

// ---- Static site ----
app.use(
  express.static(PUBLIC_DIR, {
    extensions: ['html'],
    maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0,
  })
);

// Fallback to index.html for the root and any unmatched non-API route
// (keeps this correct if the site ever grows extra pages/anchors).
app.get(/^\/(?!api\/).*/, (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// ---- 404 for unmatched API routes ----
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Not found.' });
});

// ---- Central error handler ----
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Malformed request body.' });
  }
  console.error('[unhandled]', err);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`Kalale Research server running at http://localhost:${PORT}`);
});

module.exports = app;
