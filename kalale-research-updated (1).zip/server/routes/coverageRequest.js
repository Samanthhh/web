'use strict';

const express = require('express');
const rateLimit = require('express-rate-limit');
const { JSONStore } = require('../store');
const { rejectHoneypot, validateCoverageRequest } = require('../middleware/validate');

const router = express.Router();
const requests = new JSONStore('coverage-requests.json');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please try again later.' },
});

router.post('/', limiter, rejectHoneypot, validateCoverageRequest, async (req, res) => {
  try {
    const { name, email, target, message } = req.body;
    const { record } = await requests.append({
      name,
      email,
      target,
      message,
      status: 'new',
      requestedAt: new Date().toISOString(),
    });

    return res.status(201).json({ ok: true, id: record.requestedAt });
  } catch (err) {
    console.error('[coverage-request] failed:', err);
    return res.status(500).json({ error: 'Could not save your request. Please try again.' });
  }
});

module.exports = router;
