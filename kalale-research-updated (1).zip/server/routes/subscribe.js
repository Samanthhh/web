'use strict';

const express = require('express');
const rateLimit = require('express-rate-limit');
const { JSONStore } = require('../store');
const { rejectHoneypot, validateSubscribe } = require('../middleware/validate');

const router = express.Router();
const subscribers = new JSONStore('subscribers.json');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please try again later.' },
});

router.post('/', limiter, rejectHoneypot, validateSubscribe, async (req, res) => {
  try {
    const { email } = req.body;
    const { record, duplicate } = await subscribers.append(
      { email, subscribedAt: new Date().toISOString() },
      (existing, incoming) => existing.email === incoming.email
    );

    // Hook point: send a confirmation email here once SMTP credentials are
    // configured (e.g. via nodemailer + env vars). Left out by default so
    // the server runs with zero external accounts required.

    return res.status(duplicate ? 200 : 201).json({
      ok: true,
      alreadySubscribed: duplicate,
      email: record.email,
    });
  } catch (err) {
    console.error('[subscribe] failed:', err);
    return res.status(500).json({ error: 'Could not save your subscription. Please try again.' });
  }
});

module.exports = router;
